            <table width="800" border="0" class="cardprofile">
                <tbody class="tcuerpo">
                    <tr>
                        <td width="370" height="250">
                            <img style="margin-left:15px" class="sombra" src="{{ asset('/img/concejo/Helmer Fernandez Chaparro.jpg')}}">

                        </td>
                        
                        <td style="padding: 0 ">
                            <table border="0">
                                <tbody>
                                    <tr>
                                        <td  class="text-titulo pull-left" ><b style="color:#2e8ece"> ALCALDE DISTRITAL</b></td>
                                    </tr>
                                    <tr>
                                       <td class="text-titulo pull-left">C.P.C. Helmer Joel Fernandez Chaparro</td>
                                       
                                    </tr>
                                    <tr>
                                        <td class="text-titulo pull-left">HFernandez@municiudadnueva.gob.pe</td>
                                        
                                    </tr>
                                </tbody>
                            </table>    
                        </td>
                    </tr>
                </tbody>
            </table>
            
            <hr style="color: #0056b2;" /> <!-- separacion horizontal entre filas -->

<table width="800" border="0" class="cardprofile">
                <tbody class="tcuerpo">
                    <tr>
                        <td width="370" height="250">
                            <img style="margin-left:15px" class="sombra" src="{{ asset('/img/concejo/Duverly Jose Clemente Ticona.jpg')}}" alt="" width="auto" height="230" border="0">
                        </td>
                        
                        <td style="padding: 0 ">
                            <table border="0">
                                <tbody class="tcuerpo">
                                    
                                    <tr>
                                        <td><b style="color:#2e8ece">Regidor :  </b></td>
                                        <td class="text-titulo pull-left">Dr. Duverly Jose Clemente Ticona</td>
                                    </tr>
                                    <tr>
                                        <td><b style="font-weight:bold; color:#2e8ece;">Correo Institucional: </b></td>
                                        <td class="text-titulo pull-left">  DClemente@municiudadnueva.gob.pe</td>
                                    </tr>
                                </tbody>
                            </table>                                                                                        
                        </td>
                        
                    </tr>
                </tbody>
            </table>
            
            <hr style="color: #0056b2;" />   <!-- separacion horizontal entre filas -->
            
            <table width="800" border="0" class="cardprofile">
                <tbody class="tcuerpo">
                    <tr>
                        <td width="370" height="250">
                            <img style="margin-left:15px" class="sombra " src="{{ asset('/img/concejo/David Anchapuri Manuelo.jpg')}}" alt="" width="auto" height="230" border="0">
                        </td>
                        <td style="padding: 0 ">

                            <table border="0">
                                <tbody class="tcuerpo">
                                    
                                    <tr>
                                        <td><b style="color:#2e8ece">Regidor :  </b></td>
                                        <td class="text-titulo pull-left">Sr. David Anchapuri Manuelo</td>
                                    </tr>
                                    <tr>
                                        <td><b style="font-weight:bold; color:#2e8ece;">Correo Institucional: </b></td>
                                        <td class="text-titulo pull-left">  Danchapuri@municiudadnueva.gob.pe</td>
                                    </tr>
                                </tbody>
                            </table>                                                                                        
                        </td>
                    </tr>
                </tbody>
            </table>
            
            <hr style="color:#0056b2;" />   <!-- separacion horizontal entre filas -->

            <table width="800" border="0" class="cardprofile">
                <tbody class="tcuerpo">
                    <tr>
                        <td width="370" height="250">
                            <img style="margin-left:15px" class="sombra" src="
                            {{ asset('/img/concejo/Adrian Candia Chura.jpg')}}" alt="" width="auto" height="230" border="0">
                        </td>
                        
                        <td style="padding: 0 ">
                            <table border="0">
                                <tbody class="tcuerpo">
                                    
                                    <tr>
                                        <td><b style="color:#2e8ece">Regidor :  </b></td>
                                        <td class="text-titulo pull-left"> Sr. Adrian Candia Chura </td>
                                    </tr>
                                    <tr>
                                        <td><b style="font-weight:bold; color:#2e8ece;">Correo Institucional: </b></td>
                                        <td class="text-titulo pull-left"> Acandia@municiudadnueva.gob.pe</td>
                                    </tr>
                                </tbody>
                            </table>                                                                                        
                        </td>
                  
                    </tr>
                </tbody>
            </table>
            
            <hr style="color:0056b2;" />    <!-- separacion horizontal entre filas -->
        
            <table width="800" border="0" class="cardprofile">
                <tbody class="tcuerpo">
                    <tr>
                        
                        <td width="370" height="250">
                            <img style="margin-left:15px" class="sombra" src="{{ asset('/img/concejo/Juan Rene Cachicatari Quispe.jpg')}} " alt="" width="auto" height="230" border="0">
                        </td>
                        
                        <td style="padding: 0 ">
                            <table border="0">
                                <tbody class="tcuerpo">
                                    
                                    <tr>
                                        <td><b style="color:#2e8ece">Regidor :  </b></td>
                                        <td class="text-titulo pull-left">Sr. Juan Rene Cachicatari Quispe</td>
                                    </tr>
                                    <tr>
                                        <td><b style="font-weight:bold; color:#2e8ece;">Correo Institucional: </b></td>
                                        <td class="text-titulo pull-left">  JCachicatari@municiudadnueva.gob.pe</td>
                                    </tr>
                                </tbody>
                            </table>                                                                                        
                        </td>
                        
                    </tr>
                </tbody>
            </table>
            
            <hr style="color=#0056b2;" /> <!-- separacion horizontal entre filas -->

            <table width="800" border="0" class="cardprofile">
                <tbody class="tcuerpo">
                    <tr>
                        <td width="370" height="250">
                            <img style="margin-left:15px" class="sombra" src="{{ asset('/img/concejo/Elvira Flor Gonzales Guillermo.jpg')}}" alt="" width="auto" height="230" border="0">
                        </td>
                        <td style="padding: 0 ">

                            <table border="0">
                                <tbody class="tcuerpo">
                                    
                                    <tr>
                                        <td><b style="color:#2e8ece">Regidor :  </b></td>
                                        <td class="text-titulo pull-left">Dra. Elvira Flor Gonzales Guillermo </td>
                                    </tr>
                                    <tr>
                                        <td><b style="font-weight:bold; color:#2e8ece;">Correo Institucional: </b></td>
                                        <td class="text-titulo pull-left">  EGonzales@municiudadnueva.gob.pe</td>
                                    </tr>
                                </tbody>
                            </table>                                                                                        
                        </td>
                    </tr>
                </tbody>
            </table>
            
            <hr style="color=#0056b2;" /> <!-- separacion horizontal entre filas -->

            <table width="800" border="0" class="cardprofile">
                <tbody class="tcuerpo">
                    <tr>
                        <td width="370" height="250">
                            <img style="margin-left:15px" class="sombra" src="{{ asset('/img/concejo/Javier.jpg')}}" alt="" width="auto" height="230" border="0">
                        </td>
                        
                        <td style="padding: 0 ">
                            <table border="0">
                                <tbody class="tcuerpo">
                                    <tr>
                                        <td><b style="color:#2e8ece">Regidor :  </b></td>
                                        <td class="text-titulo pull-left">Sr. Abel Javier Japura Yucra</td>
                                    </tr>
                                    <tr>
                                        <td><b style="font-weight:bold; color:#2e8ece;">Correo Institucional: </b></td>
                                        <td class="text-titulo pull-left">  AJapura@municiudadnueva.gob.pe</td>
                                    </tr>
                                </tbody>
                            </table>                                                                                        
                        </td>
                        
                    </tr>
                </tbody>
            </table>
            
            <hr style="color=#0056b2;" /> <!-- separacion horizontal entre filas -->

            <table width="800" border="0" class="cardprofile">
                <tbody class="tcuerpo">
                    <tr>
                        <td width="370" height="250">
                            <img style="margin-left:15px" class="sombra" src="{{ asset('/img/concejo/Percy Francisco Ticona Apaza.jpg')}}" alt="" width="auto" height="230" border="0">
                        </td>
                        
                        <td style="padding: 0 ">
                            <table border="0">
                                <tbody class="tcuerpo">
                                    <tr>
                                        <td><b style="color:#2e8ece">Regidor :  </b></td>
                                        <td class="text-titulo pull-left">Sr. Percy Francisco Ticona Apaza</td>
                                    </tr>
                                    
                                    <tr>
                                        <td><b style="font-weight:bold; color:#2e8ece;">Correo Institucional: </b></td>
                                        <td class="text-titulo pull-left">  PTicona@municiudadnueva.gob.pe</td>
                                    </tr>
                                </tbody>
                            </table>                                                                                        
                        </td>
                    </tr>
                </tbody>
            </table>