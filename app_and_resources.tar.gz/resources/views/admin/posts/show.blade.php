<div id="modalMostrarmenu" class="modal container fade" data-width="1100" tabindex="-1" data-focus-on="input:first" data-backdrop="static" data-keyboard="false" style="display: none;">

	<div class="modal-header">
			<button type="button" data-dismiss="modal" aria-hidden="true" class="close">×</button>
		<h4 class="solsoModalTitle"><b>Menú</b></h4>
	</div>
	<div class="modal-body">
		<div class="row solsoShowForm">

			<div class=" col-md-12">
				<h1 id="name-menu" class="modal-show"></h1>
				<hr>

				<table class="table table-striped" style="text-align: center;">
				<tbody>
					<div id="imagen-menu" class="col-md-6 modal-show" >
						<img id="" src="" class="img-responsive">
					</div>
					<div class="col-md-6">
						<tr>
							<div class="col-xs-6 col-sm-3 col-md-3"><b>Contenido:</b></div>
							<div class="col-xs-6 col-sm-3 col-md-3" id="content-menu"></div>
						</tr>
						<tr>
							<div class="col-xs-6 col-sm-3 col-md-3"><b>Publicado:</b></div>
							<div class="col-xs-6 col-sm-3 col-md-3" id="published-menu"></div>
						</tr>
					</div>
				</tbody>
				</table>
			</div>
		</div>
	</div>
	<div class="modal-footer">
		<button type="reset" class="btn btn-default solsoCancel" data-dismiss="modal" id="cerrar-show-menu">Cancelar</button>
	</div>
</div>