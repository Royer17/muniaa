  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b></b> 
    </div>
    <strong>Copyright &copy; 2021 <a href="#"> Municipalidad Distrital de Calana</a>.</strong> Todos los Derechos Reservados.
  </footer>